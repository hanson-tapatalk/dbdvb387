<?php

defined('IN_MOBIQUO') or exit;

require_once('./global.php');

function update_push_status_func($xmlrpc_params)
{
    global $vbulletin, $db, $return_status, $return_text;
    
    $decode_params = php_xmlrpc_decode($xmlrpc_params);
    
    $userid = $vbulletin->userinfo['userid'];
    $status = false;
    
    if ($vbulletin->db->query_first("SHOW TABLES LIKE '" . TABLE_PREFIX . "tapatalk_users'"))
    {
        if (empty($userid) && isset($decode_params[1]) && isset($decode_params[2]))
        {
            $username = mobiquo_encode($decode_params[1], 'to_local');
            $password = mobiquo_encode($decode_params[2], 'to_local');
            
            if ($username && $password)
            {
                $vbulletin->GPC['username'] = $username;
                if(strlen($password) == 32) {
                    $vbulletin->GPC['md5password'] = $password;
                    $vbulletin->GPC['md5password_utf'] = $password;
                } else {
                    $vbulletin->GPC['password'] = $password;
                }
                
                require_once(DIR . '/includes/functions_login.php');
                
                if (verify_authentication($vbulletin->GPC['username'], $vbulletin->GPC['password'], $vbulletin->GPC['md5password'], $vbulletin->GPC['md5password_utf'], $vbulletin->GPC['cookieuser'], false))
                {
                    $userid = $vbulletin->userinfo['userid'];
                }
            }
        }
        
        if ($userid)
        {
            $update_params = array();
            if (isset($decode_params[0]['all']))
            {
                $update_params[] = 'announcement='.($decode_params[0]['all'] ? 1 : 0);
                $update_params[] = 'pm='.($decode_params[0]['all'] ? 1 : 0);
                $update_params[] = 'subscribe='.($decode_params[0]['all'] ? 1 : 0);
                $update_params[] = 'quote='.($decode_params[0]['all'] ? 1 : 0);
                $update_params[] = 'newtopic='.($decode_params[0]['all'] ? 1 : 0);
                $update_params[] = 'tag='.($decode_params[0]['all'] ? 1 : 0);
            }
            else
            {
                if (isset($decode_params[0]['ann']))
                    $update_params[] = 'announcement='.($decode_params[0]['ann'] ? 1 : 0);
                
                if (isset($decode_params[0]['pm']))
                    $update_params[] = 'pm='.($decode_params[0]['pm'] ? 1 : 0);
                
                if (isset($decode_params[0]['sub']))
                    $update_params[] = 'subscribe='.($decode_params[0]['sub'] ? 1 : 0);

                if (isset($decode_params[0]['quote']))
                    $update_params[] = 'quote='.($decode_params[0]['quote'] ? 1 : 0);

                if (isset($decode_params[0]['newtopic']))
                    $update_params[] = 'newtopic='.($decode_params[0]['newtopic'] ? 1 : 0);

                if (isset($decode_params[0]['tag']))
                    $update_params[] = 'tag='.($decode_params[0]['tag'] ? 1 : 0);                    
                    
            }
            
            if ($update_params)
            {
                $update_params_str = implode(', ', $update_params);
                $update_params_str .= ',updated='.time();
                $db->query_write("
                    UPDATE " . TABLE_PREFIX . "tapatalk_users
                    SET $update_params_str
                    WHERE userid = '$userid'
                ");
            }
            
            $status = true;
        }
    }
    
    return new xmlrpcresp(new xmlrpcval(array(
        'result' => new xmlrpcval($status, 'boolean'),
    ), 'struct'));
}