<?php

require_once('./global.php');

function sign_in_func($xmlrpc_params)
{
    global $vbulletin;

    $params = php_xmlrpc_decode($xmlrpc_params);

    $need_email_verification = true;

    $_POST['token'] = mobiquo_encode($params[0], 'to_local');
    $_POST['code'] = mobiquo_encode($params[1], 'to_local');
    $_POST['email'] = mobiquo_encode($params[2], 'to_local');
    $_POST['username'] = mobiquo_encode($params[3], 'to_local');
    $_POST['password'] = mobiquo_encode($params[4], 'to_local');
    $_POST['password_md5'] = md5($_POST['password']);

    include(DIR.'/'.$vbulletin->options['tapatalk_directory'].'/include/function_push.php');

    //Check if push key exist
    if(!isset($vbulletin->options['push_key']) || empty($vbulletin->options['push_key']))
        return return_fault('Forum is not configured well, please contact administrator to set up push key for the forum!');
    if(!empty($_POST['token']))
        $email_response = getEmailFromScription($_POST['token'], $_POST['code'], $vbulletin->options['push_key']);

    if(empty($email_response))
        return return_fault('Failed to connect to tapatalk server, please try again later.');


    $response_verified = $email_response['result'] && isset($email_response['email']) && !empty($email_response['email']);
    if(!$response_verified)
        return return_fault(isset($email_response['result_text'])? $email_response['result_text'] : 'Tapatalk ID session expired, please re-login Tapatalk ID and try again, if the problem persist please tell us.');
    
    // Sign in logic
    if(!empty($_POST['email']))
    {
        if($email_response['email'] == $_POST['email'])
        {
            $user = get_user_by_NameorEmail($_POST['email']);
            if(isset($user['userid']) && !empty($user['userid']))
            {
                return login_user($user);
            }
            else
            {
                if(!empty($_POST['username']))
                {
                    $user = get_user_by_NameorEmail($_POST['username']);
                    $username_exist = isset($user['userid']) && !empty($user['userid']);
                    
                    //gavatar? vb don't support
                    
                    $reg_response = register_user();

                    if(is_array($reg_response))
                    {
                        list($user_id, $result_text) = $reg_response;
        
                        if($user_id != 0) 
                        {
                            // register succeed, try to add custom avatar
                            if(isset($email_response['avatar_url'])&& !empty($email_response['avatar_url']))
                            {
                                try
                                {
                                    $aurl = $email_response['avatar_url'];
                                    $avatarModel = $bridge->getModelFromCache('XenForo_Model_Avatar');
                                    $avatarData = $avatarModel->applyAvatar($user_id, $email_response['avatar_url']);
                                }
                                catch(Exception $e){}
                            }
                            
                            $user = mobiquo_verify_id('user', $user_id, 0, 1);
                            
                            return login_user($user); // login if registered
                        }
                        else
                        {
                            return error_status($username_exist ? '1' : '0', $result_text);
                        }
                    }
                    else
                    {
                        $result_text = (string) $reg_response;
                        return error_status($username_exist ? '1' : '0', $result_text);
                    }
                }
                else
                {
                    return error_status(2);
                }
            }
        }
        else
        {
            return error_status(3);
        }
    }
    else if(!empty($_POST['username']))
    {
        $user = get_user_by_NameorEmail($_POST['username']);

        if(isset($user['userid']) && !empty($user['userid']) && $user['email'] == $email_response['email'])
        {
            return login_user($user);
        }
        else
        {
            return error_status(3);
        }
    }
    else
    {
        return return_fault('Application Error : either email or username should provided.');
    }

}

function error_status($status = 0, $result_text = '')
{
    $result = new xmlrpcval(array(
        'result'        => new xmlrpcval(false, 'boolean'),
        'status'        => new xmlrpcval($status, 'string'),
        'result_text'   => new xmlrpcval($result_text, 'base64'),
    ), 'struct');

    return new xmlrpcresp($result);
}

function login_user($user)
{
    global $vbulletin, $tt_config;

    
    $username = $user['username'];
    $password = $user['password'];
    $vbulletin->userinfo = $user;
    $vbulletin->GPC['logintype'] = null;
    require_once(DIR . '/includes/functions_login.php');
    require_once(DIR . '/includes/functions_user.php');
    
    if (true)
    {
        $return = array();
        $vbulletin->GPC['username'] =$username;
        if(strlen($password) == 32){
            $vbulletin->GPC['md5password'] = $password;
            $vbulletin->GPC['md5password_utf'] = $password;
        } else {
            $vbulletin->GPC['password'] = $password;
        }

        if ($vbulletin->GPC['username'] == '')
        {
            return_fault('You have entered an invalid username or password.');
        }


        // make sure our user info stays as whoever we were (for example, we might be logged in via cookies already)
        $original_userinfo = $vbulletin->userinfo;

            exec_unstrike_user($vbulletin->GPC['username']);


            $member_groups = preg_split("/,/",$vbulletin->userinfo['membergroupids']);
            $group_block = false;

            if(trim($tt_config['allowed_usergroup']) != "")
            {
                $group_block = true;
                $support_group = explode(',', $tt_config['allowed_usergroup']);

                foreach($support_group as $support_group_id)
                {
                    $support_group_id = trim($support_group_id);
                    if($vbulletin->userinfo['usergroupid'] == $support_group_id || in_array($support_group_id,$member_groups)) {
                        $group_block = false;
                    }
                }
            }

            $return_group_ids = array();
            foreach($member_groups AS $id)
            {
                if($id) {
                    array_push($return_group_ids, new xmlrpcval($id, 'string'));
                }
            }
            
            array_push($return_group_ids, new xmlrpcval($vbulletin->userinfo['usergroupid'], 'string'));

            if($group_block){
                $return_text = 'The usergroup you belong to does not have permission to login. Please contact your administrator. ';
                $return = new xmlrpcresp(new xmlrpcval(array(
                    'result'        => new xmlrpcval(false, 'boolean'),
                    'result_text'   => new xmlrpcval(mobiquo_encode($return_text), 'base64'),
                ), 'struct'));

            } else {
                if (!empty($vbulletin->session->userinfo) && $vbulletin->session->userinfo['userid'] == 0 ) $vbulletin->session->userinfo = false;
                process_new_login($vbulletin->GPC['logintype'], $vbulletin->GPC['cookieuser'], $vbulletin->GPC['cssprefs']);
                $vbulletin->session->save();
                $permissions = cache_permissions($vbulletin->userinfo);
                $pmcount = $vbulletin->db->query_first("
                    SELECT
                        COUNT(pmid) AS pmtotal
                    FROM " . TABLE_PREFIX . "pm AS pm
                    WHERE pm.userid = '" . $vbulletin->userinfo['userid'] . "'
                ");
                
                $pmcount['pmtotal'] = intval($pmcount['pmtotal']);
                $show['pmmainlink'] = ($vbulletin->options['enablepms'] AND ($vbulletin->userinfo['permissions']['pmquota'] OR $pmcount['pmtotal']));
                $show['pmsendlink'] = ($vbulletin->userinfo['permissions']['pmquota']);
                if (!($vbulletin->userinfo['permissions']['forumpermissions'] & $vbulletin->bf_ugp_forumpermissions['canview'])){
                    if (!($vbulletin->usergroupcache["$usergroupid"]['genericoptions'] & $vbulletin->bf_ugp_genericoptions['isnotbannedgroup']))
                    {
                        $result_text = "You have been banned at this forum";
                    } else {
                        $result_text = "You do not have permission to access this forum.";
                    }
                }
                
                $mobiquo_userinfo = mobiquo_verify_id('user', $vbulletin->userinfo['userid'], 0, 1, $fetch_userinfo_options);

                //generate usergroups
                $usergroupstr = $mobiquo_userinfo['usergroupid'];
                if(isset($mobiquo_userinfo['membergroupids']) && !empty($mobiquo_userinfo['membergroupids']))
                    $usergroupstr .= ','.$mobiquo_userinfo['membergroupids'];
                $usergroups = explode(',', $usergroupstr);
                //check allow usergroup
                if(isset($vbulletin->options['tp_allow_usergroup']) && !empty($vbulletin->options['tp_allow_usergroup']))
                {
                    $allow_tapatalk = false;
                    $allow_usergroups = explode(',', $vbulletin->options['tp_allow_usergroup']);
                    foreach($usergroups as $group_id)
                    {
                        if(in_array($group_id, $allow_usergroups))
                            $allow_tapatalk = true;
                    }
                    if(!$allow_tapatalk)
                        return return_fault('You are not allowed to login via Tapatalk, please contact your forum administrator.');
                }
                
                if ($vbulletin->userinfo['userid'] AND $vbulletin->userinfo['permissions']['passwordexpires'])
                {
                    $passworddaysold = floor((TIMENOW - $mobiquo_userinfo['passworddate']) / 86400);

                    if ($passworddaysold >= $vbulletin->userinfo['permissions']['passwordexpires'])
                    {
                        $result_text = "Your password is ".$passworddaysold." days old, and has therefore expired.";
                    }
                }

                if (isset($decode_params[2]) && $decode_params[2])
                {
                    return new xmlrpcresp(new xmlrpcval(array(
                        'result'        => new xmlrpcval(true, 'boolean'),
                        'result_text'   => new xmlrpcval($result_text, 'base64'),
                    ), 'struct'));
                }

                $max_png_size = $vbulletin->userinfo['attachmentpermissions']['png']['permissions'] ? $vbulletin->userinfo['attachmentpermissions']['png']['size'] : 0;
                $max_jpg_size = $vbulletin->userinfo['attachmentpermissions']['jpeg']['permissions'] ? $vbulletin->userinfo['attachmentpermissions']['jpeg']['size'] : 0;
                $max_attachment = $vbulletin->options['attachlimit'] ? $vbulletin->options['attachlimit'] : 100;
                $can_whosonline = $vbulletin->options['WOLenable'] && $permissions['wolpermissions'] & $vbulletin->bf_ugp_wolpermissions['canwhosonline'];
                $can_search = $vbulletin->options['enablesearches'] && $permissions['forumpermissions'] & $vbulletin->bf_ugp_forumpermissions['cansearch'];
                $can_upload_avatar = $permissions['genericpermissions'] & $vbulletin->bf_ugp_genericpermissions['canuseavatar'];
                $push_status = array();
                if($vbulletin->options['tapatalk_push'])
                {
                    $user_id = $vbulletin->userinfo['userid'];
                    $query = $vbulletin->db->query_read_slave("SELECT * FROM ". TABLE_PREFIX . "tapatalk_users WHERE userid = $user_id");
                    $items = $vbulletin->db->fetch_array($query);
                    foreach($items as $name => $value)
                    {
                        $display_name = getStarndardNameByTableKey($name);
                        if($display_name)
                        {
                            $push_status[] = new xmlrpcval(array(
                                'name'  => new xmlrpcval($display_name, 'string'),
                                'value' => new xmlrpcval((boolean)$value, 'boolean')
                            ), 'struct');
                        }
                    }
                }                
                if (isset($decode_params[3]) && $decode_params[3])
                    update_push();
                
                $return_array = array(
                    'result'            => new xmlrpcval(true, 'boolean'),
                    'result_text'       => new xmlrpcval($result_text, 'base64'),
                    'user_id'           => new xmlrpcval($vbulletin->userinfo['userid'], 'string'),
                    'username'          => new xmlrpcval(mobiquo_encode($vbulletin->userinfo['username']), 'base64'),
                    'user_type'         => new xmlrpcval(get_usertype_by_item($vbulletin->userinfo['userid']), 'base64'),
                    'email'             => new xmlrpcval(mobiquo_encode($mobiquo_userinfo['email']), 'base64'),
                    'usergroup_id'      => new xmlrpcval($return_group_ids, 'array'),
                    'icon_url'          => new xmlrpcval(mobiquo_get_user_icon($vbulletin->userinfo['userid']), 'string'),
                    'post_count'        => new xmlrpcval($mobiquo_userinfo['posts'], 'int'),
                    'can_pm'            => new xmlrpcval($show['pmmainlink'], 'boolean'),
                    'can_send_pm'       => new xmlrpcval(($show['pmmainlink'] AND $show['pmsendlink']), 'boolean'),
                    'can_moderate'      => new xmlrpcval(can_moderate(), 'boolean'),
                    'can_search'        => new xmlrpcval($can_search, 'boolean'),
                    'can_whosonline'    => new xmlrpcval($can_whosonline, 'boolean'),
                    'can_upload_avatar' => new xmlrpcval($can_upload_avatar, 'boolean'),
                    'max_attachment'    => new xmlrpcval($max_attachment, 'int'),
                    'max_png_size'      => new xmlrpcval(intval($max_png_size), 'int'),
                    'max_jpg_size'      => new xmlrpcval(intval($max_jpg_size), 'int'),
                );
                if(isset($push_status) && !empty($push_status))
                    $return_array['push_type'] =  new xmlrpcval($push_status, 'array');
                $return = new xmlrpcresp(new xmlrpcval($return_array, 'struct'));
            }
    }
    else
    {
        $return =new xmlrpcval(array(
            'result' => new xmlrpcval(false, 'boolean'),
        ), 'struct');
    }

    return $return;
}

function getStarndardNameByTableKey($key)
{
    $starndard_key_map = array(
        'conv'     => 'conv',
        'pm'       => 'pm',
        'subscribe'=> 'sub',
        'liked'    => 'like',
        'quote'    => 'quote',
        'newtopic' => 'newtopic',
        'tag'      => 'tag',
//        'announcement'      => 'ann',
    );
    return isset($starndard_key_map[$key])? $starndard_key_map[$key]: '';
}