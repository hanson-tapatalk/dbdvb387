<?php
/*======================================================================*\
 || #################################################################### ||
 || # Copyright &copy;2009 Quoord Systems Ltd. All Rights Reserved.    # ||
 || # This file may not be redistributed in whole or significant part. # ||
 || # This file is part of the Tapatalk package and should not be used # ||
 || # and distributed for any other purpose that is not approved by    # ||
 || # Quoord Systems Ltd.                                              # ||
 || # http://www.tapatalk.com | http://www.tapatalk.com/license.html   # ||
 || #################################################################### ||
 \*======================================================================*/

defined('CWD1') or exit;

require_once(CWD1.'/config/config.php');

$phrasegroups = array();
$specialtemplates = array();
$globaltemplates = array();
$actiontemplates = array();

require_once('./global.php');

function get_config_func()
{
    global $vbulletin, $tt_config, $permissions, $db;
    
    $return_config = array(
        'sys_version' => new xmlrpcval(FILE_VERSION),
        'guest_okay'  => new xmlrpcval(isset($vbulletin->options['tapatalk_guest_okay']) ? $vbulletin->options['tapatalk_guest_okay'] : $tt_config['guest_okay'], 'boolean'),
        'push'        => new xmlrpcval(isset($vbulletin->options['tapatalk_push']) ? $vbulletin->options['tapatalk_push'] : $tt_config['push'], 'string'),
    );
    
    //Check if plugin is valid.
    $is_open = false;
    $open_result_text = 'Tapatalk Plugin is not activated in your forum';
    $product = $db->query_first("
        SELECT *
        FROM " . TABLE_PREFIX . "product
        WHERE productid = 'tapatalk'
    ");
    if($product && $product['active']  && $tt_config['is_open'] )
    {
        $config_version =  trim(str_replace('vb3x_', '', $tt_config['version']));
        if($config_version == trim($product['version']))
            $is_open = true;
        else
            $open_result_text = 'Package file version doesn\'t match with the installed version, please goto your forum\'s AdminCP->Plugin&Products-> Manage Products to upgrade by importing the latest installation xml';
    }

    $return_config['is_open'] = new xmlrpcval($is_open, 'boolean');
    if(!$is_open)
        $return_config['result_text'] = new xmlrpcval($open_result_text, 'base64');
    if(!$vbulletin->options['bbactive'])
        $return_config['result_text'] = new xmlrpcval($vbulletin->options['bbclosedreason'], 'base64');
    
    foreach($tt_config as $key => $value)
    {
        if(!$return_config[$key] && !is_array($value)) {
            $return_config[$key] = new xmlrpcval(mobiquo_encode($value), 'string');
        }
    }
    
    if (isset($vbulletin->options['tapatalk_delete_option']) && $vbulletin->options['tapatalk_delete_option']) {
        $return_config['advanced_delete'] = new xmlrpcval('1', 'string');
    }
    
    if ($vbulletin->options['enablesearches'] && $permissions['forumpermissions'] & $vbulletin->bf_ugp_forumpermissions['cansearch'])
    {
        $return_config['guest_search'] = new xmlrpcval('1', 'string');
    }
    
    if ($vbulletin->options['WOLenable'] && $permissions['wolpermissions'] & $vbulletin->bf_ugp_wolpermissions['canwhosonline'])
    {
        $return_config['guest_whosonline'] = new xmlrpcval('1', 'string');
    }
    
    return new xmlrpcresp(new xmlrpcval($return_config, 'struct'));
}
