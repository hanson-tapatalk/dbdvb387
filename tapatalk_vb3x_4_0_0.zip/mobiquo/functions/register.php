<?php

require_once('./global.php');

function register_func($xmlrpc_params)
{
    global $vbulletin;

    $params = php_xmlrpc_decode($xmlrpc_params);

    $need_email_verification = true;
    $_POST['username'] = mobiquo_encode($params[0], 'to_local');
    $_POST['password'] = mobiquo_encode($params[1], 'to_local');
    $_POST['email'] = mobiquo_encode($params[2], 'to_local');
    $_POST['password_md5'] = md5($_POST['password']);
    if(isset($params[3]))
    {
        include(DIR.'/'.$vbulletin->options['tapatalk_directory'].'/include/function_push.php');

        //Check if push key exist
        if(!isset($vbulletin->options['push_key']) || empty($vbulletin->options['push_key']))
            return return_fault('Forum is not configured well, please contact administrator to set up push key for the forum!');

        $email_response = getEmailFromScription($params[3], $params[4], $vbulletin->options['push_key']);

        if(empty($email_response))
            return return_fault('Failed to connect to tapatalk server, please try again later.');

        if( (!isset($user_emaill) || empty($user_emaill)) && (!isset($email_response['email']) || empty($email_response['email'])))
            return return_fault(isset($email_response['result_text']) ? $email_response['result_text'] : 'You need to input an email or re-login tapatalk id to use default email of tapatalk id.');

        $need_email_verification = isset($email_response['result']) && $email_response['result'] && isset($email_response['email']) && !empty($email_response['email']) && ($email_response['email'] == $_POST['email']) ? false : true;
    }

    $reg_response = register_user($need_email_verification);
    
    if(is_array($reg_response))
    {
        list($userid, $result_text) = $reg_response;
        $result = new xmlrpcval(array(
            'result'            => new xmlrpcval( $userid != 0 , 'boolean'),
            'result_text'       => new xmlrpcval($result_text, 'base64'),
        ), 'struct');
    }
    else
    {
        $result_text = (string) $reg_response;
        $result = new xmlrpcval(array(
            'result'        => new xmlrpcval(false, 'boolean'),
            'result_text'   => new xmlrpcval($result_text, 'base64'),
        ), 'struct');

    }
    return new xmlrpcresp($result);
}

