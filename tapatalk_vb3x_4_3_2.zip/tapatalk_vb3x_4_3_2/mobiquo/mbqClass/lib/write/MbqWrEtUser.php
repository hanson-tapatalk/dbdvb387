<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseWrEtUser');

/**
 * user write class
 * 
 * @since  2012-9-28
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqWrEtUser extends MbqBaseWrEtUser {
    
    public function __construct() {
    }
  
}

?>