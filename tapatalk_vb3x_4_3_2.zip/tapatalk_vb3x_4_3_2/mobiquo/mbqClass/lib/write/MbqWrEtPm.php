<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseWrEtPm');

/**
 * private message write class
 * 
 * @since  2012-12-29
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqWrEtPm extends MbqBaseWrEtPm {
    
    public function __construct() {
    }
  
}

?>