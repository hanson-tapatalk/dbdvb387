<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseWrEtForum');

/**
 * forum write class
 * 
 * @since  2012-9-14
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqWrEtForum extends MbqBaseWrEtForum {
    
    public function __construct() {
    }
  
}

?>