<?php

require_once('./global.php');

function register_func($xmlrpc_params)
{
    global $vbulletin, $tt_config;

    $params = php_xmlrpc_decode($xmlrpc_params);

    $need_email_verification = true;
    $_POST['username'] = mobiquo_encode($params[0], 'to_local');
    $_POST['password'] = mobiquo_encode($params[1], 'to_local');
    $_POST['email'] = mobiquo_encode($params[2], 'to_local');
    $_POST['password_md5'] = md5($_POST['password']);

    if(!$tt_config['native_register']) return return_fault('Application Error : native registration is not supported currently.');

    if(isset($params[3]))
    {
        if(!$tt_config['sso_register']) return return_fault('Application Error : social registration is not supported currently.');
        include(DIR.'/'.$vbulletin->options['tapatalk_directory'].'/include/function_push.php');
        $email_response = getEmailFromScription($params[3], $params[4], $vbulletin->options['push_key']);
        $need_email_verification = isset($email_response['result']) && $email_response['result'] && isset($email_response['email']) && !empty($email_response['email']) && ($email_response['email'] == $_POST['email']) ? false : true;
    }

    $reg_response = register_user($need_email_verification);
    
    if(is_array($reg_response))
    {
        list($userid, $result_text) = $reg_response;
        $result = new xmlrpcval(array(
            'result'            => new xmlrpcval( $userid != 0 , 'boolean'),
            'result_text'       => new xmlrpcval($result_text, 'base64'),
        ), 'struct');
    }
    else
    {
        $result_text = (string) $reg_response;
        $result = new xmlrpcval(array(
            'result'        => new xmlrpcval(false, 'boolean'),
            'result_text'   => new xmlrpcval($result_text, 'base64'),
        ), 'struct');

    }
    return new xmlrpcresp($result);
}

