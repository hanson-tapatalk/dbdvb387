<?php

require_once('./global.php');
require_once(DIR . '/includes/functions_user.php');

function prefetch_account_func($xmlrpc_params)
{
    global $vbulletin;

    $params = php_xmlrpc_decode($xmlrpc_params);

    $email = mobiquo_encode($params[0], 'to_local');
    if(!empty($email))
    {
        $user = get_user_by_NameorEmail($email);
        
        $fetch_userinfo_options = (
            FETCH_USERINFO_AVATAR | FETCH_USERINFO_LOCATION |
            FETCH_USERINFO_PROFILEPIC | FETCH_USERINFO_SIGPIC |
            FETCH_USERINFO_USERCSS | FETCH_USERINFO_ISFRIEND
        );

        $userinfo = mobiquo_verify_id('user', $user['userid'], 1, 1, $fetch_userinfo_options);
        if(!empty($userinfo) && is_array($userinfo))
        {
            fetch_avatar_from_userinfo($userinfo, true, false);
            $result = new xmlrpcval(array(
                'result'        => new xmlrpcval(true, 'boolean'),
                'user_id'         => new xmlrpcval($userinfo['userid'], 'string'),
                'login_name'        => new xmlrpcval(mobiquo_encode($userinfo['username']), 'base64'),
                'display_name'        => new xmlrpcval(mobiquo_encode($userinfo['username']), 'base64'),
                'avatar'                => new xmlrpcval(isset($userinfo['avatarurl']) && !empty($userinfo['avatarurl'])? get_icon_real_url($userinfo['avatarurl']) : '', 'string'),
            ), 'struct');
        
            return new xmlrpcresp($result);
        }
        else
            return return_fault('Invalid email');
    }
    else
        return return_fault('Invalid email');

    return return_fault('Application Error : either email or username should provided.');
}

