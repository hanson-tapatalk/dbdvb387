<?php
/*======================================================================*\
 || #################################################################### ||
 || # Copyright &copy;2009 Quoord Systems Ltd. All Rights Reserved.    # ||
 || # This file may not be redistributed in whole or significant part. # ||
 || # This file is part of the Tapatalk package and should not be used # ||
 || # and distributed for any other purpose that is not approved by    # ||
 || # Quoord Systems Ltd.                                              # ||
 || # http://www.tapatalk.com | http://www.tapatalk.com/license.html   # ||
 || #################################################################### ||
 \*======================================================================*/

defined('CWD1') or exit;




$phrasegroups = array();





// pre-cache templates used by specific actions
$actiontemplates = array();
$specialtemplates = array(
    'userstats',
    'birthdaycache',
    'maxloggedin',
    'iconcache',
    'eventcache',
    'mailqueue'
);
$globaltemplates = array(
    'ad_forumhome_afterforums',
    'FORUMHOME',
    'forumhome_event',
    'forumhome_forumbit_level1_nopost',
    'forumhome_forumbit_level1_post',
    'forumhome_forumbit_level2_nopost',
    'forumhome_forumbit_level2_post',
    'forumhome_lastpostby',
    'forumhome_loggedinuser',
    'forumhome_moderator',
    'forumhome_subforumbit_nopost',
    'forumhome_subforumbit_post',
    'forumhome_subforumseparator_nopost',
    'forumhome_subforumseparator_post',
    'forumhome_markread_script',
    'forumhome_birthdaybit'
);

require_once('./global.php');
require_once(DIR . '/includes/functions_bigthree.php');
require_once(DIR . '/includes/functions_forumlist.php');
require_once(CWD1.'/config/config.php');

function get_config_func()
{
    global $vbulletin, $tt_config, $permissions, $db;
    
    $return_config = array(
        'sys_version' => new xmlrpcval(FILE_VERSION),
        'guest_okay'  => new xmlrpcval(isset($vbulletin->options['tapatalk_guest_okay']) ? $vbulletin->options['tapatalk_guest_okay'] : $tt_config['guest_okay'], 'boolean'),
        'push'        => new xmlrpcval('1', 'string'),
    );
    
    //Check if plugin is valid.
    $is_open = false;
    $open_result_text = 'Tapatalk Plugin is not activated in your forum';
    $product = $db->query_first("
        SELECT *
        FROM " . TABLE_PREFIX . "product
        WHERE productid = 'tapatalk'
    ");
    if($product && $product['active']  && $tt_config['is_open'] )
    {
        $config_version =  trim(str_replace('vb3x_', '', $tt_config['version']));
        if($config_version == trim($product['version']))
            $is_open = true;
        else
            $open_result_text = 'Package file version doesn\'t match with the installed version, please goto your forum\'s AdminCP->Plugin&Products-> Manage Products to upgrade by importing the latest installation xml';
    }

    $return_config['is_open'] = new xmlrpcval($is_open, 'boolean');
    if(!$is_open)
        $return_config['result_text'] = new xmlrpcval($open_result_text, 'base64');
    if(!$vbulletin->options['bbactive'])
        $return_config['result_text'] = new xmlrpcval($vbulletin->options['bbclosedreason'], 'base64');
    if(isset($vbulletin->options['push_key']) && !empty($vbulletin->options['push_key']))
    {
        $return_config['api_key'] = new xmlrpcval(md5($vbulletin->options['push_key']), 'string');
    }
    foreach($tt_config as $key => $value)
    {
        if(!$return_config[$key] && !is_array($value)) {
            $return_config[$key] = new xmlrpcval(mobiquo_encode($value), 'string');
        }
    }
    
    if (isset($vbulletin->options['tapatalk_delete_option']) && $vbulletin->options['tapatalk_delete_option']) {
        $return_config['advanced_delete'] = new xmlrpcval('1', 'string');
    }

    if ($vbulletin->options['enablesearches'] && $permissions['forumpermissions'] & $vbulletin->bf_ugp_forumpermissions['cansearch'])
    {
        $return_config['guest_search'] = new xmlrpcval('1', 'string');
    }
    
    if ($vbulletin->options['WOLenable'] && $permissions['wolpermissions'] & $vbulletin->bf_ugp_wolpermissions['canwhosonline'])
    {
        $return_config['guest_whosonline'] = new xmlrpcval('1', 'string');
    }

    //forum stastics
    {
        $show['loggedinusers'] = false;
    }
    cache_ordered_forums(1, 1);
    if ($vbulletin->options['showmoderatorcolumn'])
    {
        cache_moderators();
    }
    else if ($vbulletin->userinfo['userid'])
    {
        cache_moderators($vbulletin->userinfo['userid']);
    }
    // define max depth for forums display based on $vbulletin->options[forumhomedepth]
    define('MAXFORUMDEPTH', $vbulletin->options['forumhomedepth']);

    $forumbits = construct_forum_bit($forumid);


    // ### BOARD STATISTICS #################################################

    // get total threads & posts from the forumcache
    $totalthreads = 0;
    $totalposts = 0;
    if (is_array($vbulletin->forumcache))
    {
        foreach ($vbulletin->forumcache AS $forum)
        {
            $totalthreads += $forum['threadcount'];
            $totalposts += $forum['replycount'];
        }
    }

    // get total members and newest member from template
    $numbermembers = $vbulletin->userstats['numbermembers'];
    $newusername = $vbulletin->userstats['newusername'];
    $newuserid = $vbulletin->userstats['newuserid'];
    $activemembers = $vbulletin->userstats['activemembers'];
    $show['activemembers'] = ($vbulletin->options['activememberdays'] > 0 AND ($vbulletin->options['activememberoptions'] & 2)) ? true : false;
		$stats = array(
        'user' => new xmlrpcval($numbermembers, 'int'),
        'topic' => new xmlrpcval($totalthreads, 'int'),
        'post'   => new xmlrpcval($totalposts, 'int')
    );

    if($show['activemembers'])
    	$stats['active'] =	new xmlrpcval($activemembers, 'int');

		$return_config['stats'] = new xmlrpcval($stats, 'struct');
    return new xmlrpcresp(new xmlrpcval($return_config, 'struct'));
}
