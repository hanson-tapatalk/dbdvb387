<?php

defined('MBQ_IN_IT') or exit;

/**
 * acl base class
 * 
 * @since  2012-8-9
 * @author Wu ZeTao <578014287@qq.com>
 */
Abstract Class MbqBaseAcl {
    
    public function __construct() {
    }
  
}

?>