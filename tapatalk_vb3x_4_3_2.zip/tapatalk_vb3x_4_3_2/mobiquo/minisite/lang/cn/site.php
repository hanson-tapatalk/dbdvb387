<?php

/* SITE模块翻译 */
$mpf_lang_site = array (
);

?>