<?php
/**
 * SITE模块的字段定义类
 * 
 * @since  2010-1-1
 * @author Wu ZeTao <578014287@qq.com>
 */
Abstract Class FdtSite {

    /**
     * 构造函数
     */
    public function __construct() {
    }
    
}

?>