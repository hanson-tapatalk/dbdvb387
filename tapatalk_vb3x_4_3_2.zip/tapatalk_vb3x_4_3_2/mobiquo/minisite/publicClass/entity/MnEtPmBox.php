<?php

MainApp::$oClk->includeClass('MbqEtPmBox');

/**
 * private message box class
 * 
 * @since  2013-8-5
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MnEtPmBox extends MbqEtPmBox {
    
    public function __construct() {
        parent::__construct();
    }
  
}

?>