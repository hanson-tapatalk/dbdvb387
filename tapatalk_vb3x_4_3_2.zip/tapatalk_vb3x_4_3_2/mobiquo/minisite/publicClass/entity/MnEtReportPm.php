<?php

MainApp::$oClk->includeClass('MbqEtReportPm');

/**
 * report primary message class
 * 
 * @since  2013-8-5
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MnEtReportPm extends MbqEtReportPm {
    
    public function __construct() {
        parent::__construct();
    }
  
}

?>