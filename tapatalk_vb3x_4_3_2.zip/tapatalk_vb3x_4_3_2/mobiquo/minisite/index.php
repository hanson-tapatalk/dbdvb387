<?php

header("Location:site/MainForum.php");

?>