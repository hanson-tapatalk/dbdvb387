<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActMMovePost');

/**
 * m_move_post action
 * 
 * @since  2012-9-27
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqActMMovePost extends MbqBaseActMMovePost {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement() {
        parent::actionImplement();
    }
  
}

?>