<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActMStickTopic');

/**
 * m_stick_topic action
 * 
 * @since  2012-9-25
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqActMStickTopic extends MbqBaseActMStickTopic {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement() {
        parent::actionImplement();
    }
  
}

?>