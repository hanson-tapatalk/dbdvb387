<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActGetThreadByPost');

/**
 * get_thread_by_post action
 * 
 * @since  2013-7-12
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqActGetThreadByPost extends MbqBaseActGetThreadByPost {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement() {
        parent::actionImplement();
    }
  
}

?>