<?php

/**
 * used for add extended classes
 * 
 * @since  2013-6-4
 * @author Wu ZeTao <578014287@qq.com>
 */
//for example
//MbqMain::$oClk->reg('MbqActExttCmdName', MBQ_ACTION_PATH.'MbqActExttCmdName.php');

?>