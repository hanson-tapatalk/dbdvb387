<?php

/**
 * common config used for both tapatalk plugin and native system(forum)
 * 
 * @since  2013-7-10
 * @author Wu ZeTao <578014287@qq.com>
 */
 
Class MbqCommonConfig {
    
    public static $cfg = array();
    
}

//custom config here,for example: 
//MbqCommonConfig::$cfg['push'] = 1;
//MbqCommonConfig::$cfg['push_type'] = 'newtopic,sub';

?>