<?php

defined('IN_MOBIQUO') or exit;

// get special phrase groups
// if ($_POST['method_name'] == 'sync_user')
// {
//     $phrasegroups = array(
//     'wol',
//     'user',
//     'messaging',
//     'cprofilefield',
//     'reputationlevel',
//     'infractionlevel',
//     'posting',
//     );
// }
require_once('./global.php');
require_once(CWD1.'/config/conf_init.php');

function reset_push_slug_func()
{
    global $vbulletin;

    $code = trim($_REQUEST['code']);
    $format = isset($_REQUEST['format']) ? trim($_REQUEST['format']) : '';
    $connection = new classTTConnection();
    $response = $connection->actionVerification($code,'reset_push_slug');   
    $result = array( 'result' => false );
    if($response === true)
    {
        $query = "UPDATE ". TABLE_PREFIX . "tapatalk_push SET title = '0' WHERE userid = 0 LIMIT 1 ";
        $vbulletin->db->query_write($query);
        $result['result'] = true;
    }
    else if($response)
    {
        $result['result_text'] = $response;
    }
    $response = ($format == 'json') ? json_encode($result) : serialize($result);
    echo $response;
    exit;
}
function set_api_key_func()
{
    require_once(DIR . '/includes/adminfunctions.php');
    require_once(DIR . '/includes/adminfunctions_options.php');
    global $vbulletin;
    $code = trim($_REQUEST['code']);
    $key  = trim($_REQUEST['key']);
    $format = isset($_REQUEST['format']) ? trim($_REQUEST['format']) : '';
    $connection = new classTTConnection();
    $response = $connection->actionVerification($code,'set_api_key');
    $result = false;
    if($response === true)
    {
        $vbulletin->input->clean_array_gpc('p', array(
            'setting'  => TYPE_ARRAY,
            'advanced' => TYPE_BOOL
        ));
        $vbulletin->GPC['setting'] = array('push_key' => $key);
        save_settings($vbulletin->GPC['setting']);
        $result = true;
    }
    $data = array(
         'result' => $result,
         'result_text' => $response,
     );
    
    $response = ($format == 'json') ? json_encode($data) : serialize($data);
    echo $response;
}

function user_subscription_func(){
    global $db;

    $code = trim($_POST['code']);
    $uid = intval(trim($_POST['uid']));
    $format = isset($_POST['format']) ? trim($_POST['format']) : '';

    try {
        $connection = new classTTConnection();
        $response = $connection->actionVerification($code, 'user_subscription');

        $data = array( 'result' => false );
        if ($response !== true){
            $data['result_text'] = $response;
            echo ($format == 'json') ? json_encode($data) : serialize($data);
            exit;
        }

        $subsforumsQ = $db->query_read_slave("
            SELECT sf.forumid as fid, f.title_clean as name
            FROM " . TABLE_PREFIX . "subscribeforum as sf
            LEFT JOIN " . TABLE_PREFIX . "forum as f ON sf.forumid = f.forumid
            WHERE sf.userid = " . $uid
        );
        while ($forum = $db->fetch_array($subsforumsQ)){
            $data['forums'][] = $forum;
        }
        $substhreadQ = $db->query_read_slave("
            SELECT threadid
            FROM " . TABLE_PREFIX . "subscribethread
            WHERE userid = " . $uid
        );
        while ($thread = $db->fetch_array($substhreadQ)){
            $data['topics'][] = $thread['threadid'];
        }
        $data['result'] = true;
    }catch (Exception $e){
        $data = array(
                'result' => false,
                'result_text' => $e->getMessage(),
        );
    }
    $response = ($format == 'json') ? json_encode($data) : serialize($data);
    echo $response;
    exit;
}

function push_content_check_func(){
    global $vbulletin, $db;
    $code = trim($_POST['code']);
    $format = isset($_POST['format']) ? trim($_POST['format']) : '';
    $data = unserialize(trim($_POST['data']));

    $result = array( 'result' => false );
    try {
        $connection = new classTTConnection();
        $response = $connection->actionVerification($code, 'push_content_check');
        if ($response !== true){
            $result['result_text'] = $response;
            echo ($format == 'json') ? json_encode($result) : serialize($result);
            exit;
        }
        if(!isset($vbulletin->options['push_key']) || !isset($data['key']) || $vbulletin->options['push_key'] != $data['key']){
            $result['result_text'] = 'incorrect api key';
            echo ($format == 'json') ? json_encode($result) : serialize($result);
            exit;
        }
        if (!isset($data['dateline']) || time() - intval($data['dateline']) > 86400){
            $result['result_text'] = 'time out';
            echo ($format == 'json') ? json_encode($result) : serialize($result);
            exit;
        }
        switch ($data['type']){
            case 'newtopic':
            case 'sub':
            case 'quote':
            case 'tag':
                $query = "
                    SELECT p.postid
                    FROM " . TABLE_PREFIX . "post AS p
                    WHERE p.postid={$data['subid']}
                        AND p.threadid={$data['id']}
                        AND p.userid={$data['authorid']}
                        AND p.dateline={$data['dateline']}
                ";
                break;
            case 'pm':
                $id = $data['id'];
                if (preg_match('/_(\d+)$/', $id, $matches)){
                    $id = $matches[1];
                }
                $query = "
                    SELECT pmt.pmtextid
                    FROM " . TABLE_PREFIX. "pmtext as pmt
                    WHERE pmt.pmtextid={$id}
                        AND pmt.fromuserid={$data['authorid']}
                        AND pmt.dateline={$data['dateline']}
                ";
                break;
        }
        if (isset($query) && !empty($query)){
            $query_result = $db->query_first($query);
            if (!empty($query_result)){
                $result['result']=true;
            }
        }
    }catch (Exception $e){
        $result['result_text'] = $e->getMessage();
    }
    echo ($format == 'json') ? json_encode($result) : serialize($result);
    exit;
}