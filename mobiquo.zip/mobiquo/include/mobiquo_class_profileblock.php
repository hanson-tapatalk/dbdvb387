<?php

if (version_check())
    require_once(CWD1."/include/mobiquo_class_profileblock37.php");
else
    require_once(CWD1."/include/mobiquo_class_profileblock38.php");
