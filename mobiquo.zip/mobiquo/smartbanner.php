<?php

global $headinclude, $header, $threadinfo, $foruminfo;

$app_android_id = $vbulletin->options['tp_app_android_url'] ? $vbulletin->options['tp_app_android_url'] : '';
$app_ios_id = $vbulletin->options['tp_app_ios_id'] ? $vbulletin->options['tp_app_ios_id'] : '';
$app_banner_message = $vbulletin->options['tp_app_banner_message'] ? $vbulletin->options['tp_app_banner_message'] : '';
$app_banner_message = preg_replace('/\r\n/','<br>',$app_banner_message);
$app_location_url = get_scheme_url();
$script_to_page = array(
   'index'          => 'home',
   'showthread'     => 'topic',
   'showpostpost'   => 'post',
   'forumdisplay'   => 'forum',
);

$page_type = defined('THIS_SCRIPT') && isset($script_to_page[THIS_SCRIPT]) ? $script_to_page[THIS_SCRIPT] : 'others';
$is_mobile_skin = false;
$app_forum_name = $vbulletin->options['bbtitle'] ? $vbulletin->options['bbtitle'] : '';
$board_url = $vbulletin->options['bburl'];
$tapatalk_dir = $vbulletin->options['tapatalk_directory'];  // default as 'mobiquo'
$tapatalk_dir_url = $board_url.'/'.$tapatalk_dir;
$api_key = $vbulletin->options['push_key'];

// control banner show from tapatalk server
$TT_tapatalk_banner_control = unserialize($vbulletin->options['TT_tapatalk_banner_control']);
$TT_banner_aways_show = true;
if (isset($TT_tapatalk_banner_control) && $TT_tapatalk_banner_control['expire'] > time())
{  
    if($TT_tapatalk_banner_control['banner_control'] != 0)
    {
        $TT_banner_aways_show = false;
    }
} else {
        include_once(CWD .'/'.$tapatalk_dir . '/include/classTTConnection.php');
        $TT_banner_control = -1;
        $TT_connection = new classTTConnection();
        $TT_url = "https://verify.tapatalk.com/get_forum_info.php";
        $TT_data['key'] = md5($vbulletin->options['push_key']);
        $TT_data['url'] = $vbulletin->options['bburl'];
        $TT_response = $TT_connection->getContentFromSever($TT_url,$TT_data,'post',true);
        
        if (!empty($TT_response)) 
        {
            $TT_rsp_array = explode("\n", $TT_response);
            foreach ($TT_rsp_array as $line) {
                $TT_result = explode(":", $line, 2);
                if ($TT_result[0] == 'banner_control')
                    $TT_banner_control = $TT_result[1];
            }
        }

        if(!in_array($TT_banner_control,array(-1, 0, 1)))
            $TT_banner_control = 1;
        
        $TT_expire         = strtotime('+1 day');
        $TT_settings = array('TT_tapatalk_banner_control' => serialize(array('banner_control' => $TT_banner_control, 'expire' => $TT_expire)));
        $vbulletin->db->query_write("
            INSERT IGNORE INTO " . TABLE_PREFIX . "setting (varname, grouptitle, defaultvalue, product) values 
            ('TT_tapatalk_banner_control','TT_smartbanner_control', 1, 'tapatalk')");
        
        include_once(CWD .'/includes/adminfunctions.php');
        include_once(CWD .'/includes/adminfunctions_options.php');
        save_settings($TT_settings);

        if ($TT_banner_control != 0)
        {
            $TT_banner_aways_show = false;
        }
}
if ($TT_banner_aways_show)
{
    $app_ads_enable = 1;
    $app_banner_enable = 1;
} else {
    $app_ads_enable = $vbulletin->options['full_ads'];
    $app_banner_enable = $vbulletin->options['tapatalk_smartbanner'];
}

$app_ads_enable = $vbulletin->options['full_ads'];
$app_banner_enable = $vbulletin->options['tapatalk_smartbanner'];
$twitterfacebook_card_enabled =  $vbulletin->options['twitterfacebook_card_enabled'];
$twc_title = isset($threadinfo['title']) ? $threadinfo['title'] : (isset($foruminfo['title_clean']) ? $foruminfo['title_clean'] : '');
$twc_description = empty($threadinfo) && isset($foruminfo['description_clean']) ? $foruminfo['description_clean'] : '';

// if in hide forums, not display the banner
$TT_display = true;
$TT_hide_fids = $vbulletin->options['tapatalk_hide_forum'];
$TT_hide_array = unserialize($TT_hide_fids);
if (!empty($TT_hide_array))
{
    $TT_forumid = $vbulletin->GPC['forumid'];
    if (!empty($TT_forumid))
    {
        $TT_parentlist = $vbulletin->forumcache[$TT_forumid]['parentlist'];
        $TT_parentarray = explode(',', $TT_parentlist);
        foreach ($TT_parentarray as $value) {
            if(in_array($value, $TT_hide_array))
            {
                $TT_display = false;
            }   
        }
    }
}

if ($TT_display && file_exists(CWD .'/'.$tapatalk_dir . '/smartbanner/head.inc.php'))
    include_once(CWD .'/'.$tapatalk_dir . '/smartbanner/head.inc.php');
    
$headinclude .= isset($app_head_include) ? $app_head_include : '';


$header = '
<!-- Tapatalk Detect body start -->
<script type="text/javascript">if (typeof(tapatalkDetect) == "function") tapatalkDetect()</script>
<!-- Tapatalk Detect banner body end -->

'.$header;



function get_scheme_url()
{
    global $vbulletin;

    $baseUrl = $vbulletin->options['bburl'];
    $baseUrl = preg_replace('/https?:\/\//', 'tapatalk://', $baseUrl);
    $location = 'index';
    $other_info = array();
    $gpc = $vbulletin->GPC;

    $has_forumid = isset($vbulletin->GPC['forumid']) && !empty($vbulletin->GPC['forumid']);
    $has_threadid = isset($vbulletin->GPC['threadid']) && !empty($vbulletin->GPC['threadid']);
    $has_postid = isset($vbulletin->GPC['postid']) && !empty($vbulletin->GPC['postid']);
    if($has_forumid)
    {
        $location = 'forum';
        $other_info[] = 'fid='.$vbulletin->GPC['forumid'];
        $perpage = $vbulletin->options['maxthreads'];
        $page = $gpc['pagenumber'] > 0 ? $gpc['pagenumber']:  1;
        if($has_threadid)
        {
            $location = 'topic';
            $perpage = $vbulletin->options['maxposts'];
            $page = $gpc['pagenumber'];
            $other_info[] = 'tid='.$vbulletin->GPC['threadid'];
            if($has_postid)
            {
                $perpage = $vbulletin->options['maxposts'];
                $page = $gpc['pagenumber'];
                $location = 'post';
                $other_info[] = 'pid='.$vbulletin->GPC['postid'];
            }
        }
    }
    else if(isset($vbulletin->GPC['userid']) && !empty($vbulletin->GPC['userid']))
    {
        $location = 'profile';
        $other_info[] = 'uid='.$vbulletin->GPC['userid'];
    }
    else if(isset($_REQUEST['pmid']) && !empty($_REQUEST['pmid']))
    {
        $location = 'message';
        $other_info[] = 'mid='.$_REQUEST['pmid'];
    }
    else if(isset($vbulletin->GPC['who']))
       $location = 'online';
    else if(isset($vbulletin->GPC['searchid']))
       $location = 'search';
    else if(isset($vbulletin->GPC['logintype']))
       $location = 'login';


    $other_info_str = implode('&', $other_info);
    $scheme_url = $baseUrl. (!empty($vbulletin->userinfo['userid']) ? '?user_id='.$vbulletin->userinfo['userid'].'&' : '?') . 'location='.$location.(!empty($page) && !empty($perpage) ? "&page=$page&perpage=$perpage" : '').(!empty($other_info_str) ? '&'.$other_info_str : '');

    return $scheme_url;
}
?>
