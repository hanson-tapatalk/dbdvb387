IMPORTANT NOTE

Please note that the connection.js and yahoo-dom-event.js scripts located in the clientscript/yui directory are provided SOLEY for backwards compatability reasons and should NOT be used for any new development.

When writing new code, please refer to the replacement files in the YUI distribution filepath, ie:

	clientscript/yui/yahoo-dom-event/yahoo-dom-event.js
	clientscript/yui/connection/connection-min.js
	
Kier, September 11th 2007.