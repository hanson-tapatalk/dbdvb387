<?php

define('FILE_VERSION_VBULLETIN', '3.8.7 Patch Level 3');

?>
